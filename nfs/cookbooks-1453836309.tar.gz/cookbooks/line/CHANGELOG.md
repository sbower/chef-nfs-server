line Cookbook CHANGELOG
========================

v0.6.1 (2015-02-24)
--------------------
- Adding CHANGELOG
- Adding ChefSpec matchers
